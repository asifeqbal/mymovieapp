import { Component, OnInit } from '@angular/core';
import { AlertController } from '@ionic/angular';
import { Router } from '@angular/router';
import RegisterService from '../register.service';
import { Alert } from 'selenium-webdriver';
import { Camera, CameraOptions } from '@ionic-native/camera/ngx';
import { Geolocation } from '@ionic-native/geolocation/ngx';
import { Contacts, Contact, ContactField, ContactName } from '@ionic-native/contacts/ngx';
import { LoadingController } from '@ionic/angular';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent implements OnInit {

  lat:any;
  long:any;

  
  constructor(public alertController: AlertController, private router: Router,private registerService:RegisterService,private camera: Camera,private geolocation:Geolocation,private contacts:Contacts,private loadingController:LoadingController ) { }


  validate:any={};
  data:any={};

  onLogin(){
    this.registerService.authRemoteCustomer(this.validate).subscribe((customer) => { this.data= customer; if( typeof(this.data.email)=='string') { this.router.navigate(['movielist']);} else { this.presentAlert();} });
   
  
  }

  ngOnInit() 
  {
    
    this.presentLoading();
    this.getPosition();
    
  }

  
  async presentLoading() {
    const loading = await this.loadingController.create({
      message: 'Loading',
      duration: 2000
    });
    await loading.present();

    const { role, data } = await loading.onDidDismiss();

    console.log('Loading dismissed!');
  }
    


  // onLogin(){
   
  //   if(this.username==this.password){
  //     this.router.navigate(['/movielist']);
  //   }

    
  //   else if(this.username!= this.password){
  //     this.presentAlert();
  //     //alert("Hi");
    
  //   }   
  // }

  getPosition() {
    this.geolocation.getCurrentPosition().then((resp) => {
    // resp.coords.latitude
      // resp.coords.longitude
      this.lat= resp.coords.latitude;
      this.long = resp.coords.longitude;
      console.log(this.lat);
      console.log(this.long);
     }).catch((error) => {
       console.log('Error getting location', error);
     });
     
     let watch = this.geolocation.watchPosition();
     watch.subscribe((data) => {
      // data can be a set of coordinates, or an error (if an error occurred).
      // data.coords.latitude
      // data.coords.longitude
     });
  }


  getContacts(){
    let contact: Contact = this.contacts.create();

    contact.name = new ContactName(null, 'Smith', 'John');
    contact.phoneNumbers = [new ContactField('mobile', '6471234567')];
    contact.save().then(
      () => console.log('Contact saved!', contact),
      (error: any) => console.error('Error saving contact.', error)
    );

  }
    




 takePicture(){
 
  
  const options: CameraOptions = {
    quality: 100,
    destinationType: this.camera.DestinationType.FILE_URI,
    encodingType: this.camera.EncodingType.JPEG,
    mediaType: this.camera.MediaType.PICTURE
  }
  
  this.camera.getPicture(options).then((imageData) => {
   // imageData is either a base64 encoded string or a file URI
   // If it's base64 (DATA_URL):
   let base64Image = 'data:image/jpeg;base64,' + imageData;
  }, (err) => {
   // Handle error
  });
 }

  

  forgotPass(){
    this.router.navigate(['/forgetpass']);
  }

  register(){

    this.router.navigate(['/register']);
  }

  async presentAlert() {
    const alert = await this.alertController.create({
      header: 'Sorry',
      subHeader: 'Incurrect User Name or password',
      message: 'Please try Again',
      buttons: ['OK']
    });

    await alert.present();
  }

  }



